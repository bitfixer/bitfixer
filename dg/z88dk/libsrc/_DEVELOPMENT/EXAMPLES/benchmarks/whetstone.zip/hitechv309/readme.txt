
HITECH C CPM-80 v3.09 FOR CP/M

1. Verify correct output

C -V WHETDC.C -DNOTIMER -LF
(out of memory with optimization on)
Run on cpm emulator.

2. Create minimal binary for comparison.

C -V -O -MWHETDC.MAP WHETDC.C -LF -DNOTIMER -DNOCOMMAND -DNOPRINTF

size: text - startup + data + bss = 0x1ad5 - 0x3d + 0x19e + 0x93 = 7369 bytes from whetdc.map
appmake +rom -s 32768 -f 0 -o whetdc0.rom
appmake +inject -b whetdc0.rom -i whetdc.com -s 256 -o whetdc.rom
ticks_start = 0x13d, ticks_end = 0x136 by inspecting output wetdc.com file
ticks whetdc.rom -start 13d -end 136 -counter 99999999999
time: 637,332,104
