
SDCC COMPILE


sdcc -mz80 --max-allocs-per-node200000 --reserve-regs-iy whetstone.c -o whetdc.ihx -DNOPRINTF -DNOCOMMAND -DNOTIMER
hex2bin whetdc.ihx
size: _CODE + _HOME + _DATA = 9465 + 4852 + 146 = 14463 bytes from whetdc.map
ticks_start = 0x22b, ticks_end = 0xfca from whetdc.map
ticks whetdc.bin -start 22b -end fca -counter 99999999999
time: 2,821,354,806
