
Z88DK COMPILES

* sccz80 Classic :- sccz80 compiler using classic c library
* sccz80 New     :- sccz80 compiler using new c library
* sdcc   New     :- sdcc compiler using new c library

//////////////
SCCZ80 CLASSIC
//////////////

Unable to compile with 2d array present.

//////////
SCCZ80 NEW
//////////

Unable to compile with 2d array present.

////////
SDCC NEW
////////

1. Verify correct output

zcc +cpm -vn -SO3 -DNOTIMER -DNOSTRUCTASSIGN -DNOREG -DNOSTAT -clib=sdcc_iy --max-allocs-per-node200000 dhry_1.c dhry_2.c -o dhry

Change binary name to end in ".com" and run on cpm emulator.

2. Create minimal binary for comparison

zcc +embedded -vn -SO3 -startup=0 -DNOTIMER -DNOSTRUCTASSIGN -DNOREG -DNOSTAT -DNOPRINTF -clib=sdcc_iy --max-allocs-per-node200000 dhry_1.c dhry_2.c -o dhry -m
size: 7247 - 111 = 7136 bytes without startup code
ticks_start = 0x1bd, ticks_end = 0x345 from pi.map
ticks dhry_CODE.bin -start 1bd -end 345 -counter 99999999999
time: 257,822,927
