
HITECH-C Z80 v7.50 FOR MSDOS

Using the IDE HPDZ.EXE make a new project containing dhry_1.c and dhry_2.c

1. Verify correct output

Compile for CP/M target using max optimizations and run on cpm emulator.
(hangs with max optimization on, ok if global optimization reduced to 2)

2. Create minimal binary for comparison

* Add "#define NOPRINTF" to dhry.h with the other #defines
* Compile with selections: ROM code, binary image and full optimization but global optimization = 2.

size (from ide dialog): 1798 + 5242 = 7040 (exclude User and first ROM section which correspond to startup code)

Examine drhy21.sym to find:
ticks_start = 0x15b, ticks_end = 0x2da

ticks dhry21.bin -start 15b -end 2da -counter 99999999999
time: 301,760,038
