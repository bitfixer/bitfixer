
HITECH C CPM-80 v3.09 FOR CP/M

1. Verify correct output

C -V -O DHRY_1.C DHRY_2.C

Run on cpm emulator.

2. Create minimal binary for comparison.

C -V -DNOPRINTF -MDHRY_1.MAP DHRY_1.C DHRY_2.C
(requesting map file leads to fail if optimizer on)
size: text - startup + data + bss = 0x9e8 - 0x3d + 0x80 + 0x1456 = 7809 bytes

C -V -O -DNOPRINTF DHRY_1.C DHRY_2.C
appmake +rom -s 32768 -f 0 -o dhry0.rom
appmake +inject -b dhry0.rom -i dhry_1.com -s 256 -o dhry.rom
ticks_start = 0x19c, ticks_end = 0x334  by inspecting dhry.rom
ticks dhry.rom -start 19c -end 334 -counter 99999999999
time: 376,240,194
