
SDCC COMPILE


sdcc -mz80 -DNOTIMER -DNOSTRUCTASSIGN -DNOREG -DNOSTAT -DNOPRINTF --reserve-regs-iy --max-allocs-per-node200000 -c dhry_1.c
sdcc -mz80 -DNOTIMER -DNOSTRUCTASSIGN -DNOREG -DNOSTAT -DNOPRINTF --reserve-regs-iy --max-allocs-per-node200000 -c dhry_2.c
sdcc -mz80 -DNOTIMER -DNOSTRUCTASSIGN -DNOREG -DNOSTAT -DNOPRINTF --reserve-regs-iy --max-allocs-per-node200000 dhry_1.rel dhry_2.rel -o dhry.ihx
hex2bin dhry.ihx
size: _CODE + _INITIALIZED + _DATA = 2017 + 2 + 5204 = 7223 bytes from dhry.map
ticks_start = 0x28b, ticks_end = 0x42a from dhry.map
ticks dhry.bin -start 28b -end 42a -counter 99999999999
time: 319,842,936
