
Z88DK COMPILES

* sccz80 Classic :- sccz80 compiler using classic c library
* sccz80 New     :- sccz80 compiler using new c library
* sdcc   New     :- sdcc compiler using new c library

//////////////
SCCZ80 CLASSIC
//////////////

1. Verify correct output

zcc +cpm -vn sieve.c -o sieve -lndos
Run output on cpm emulator.

2. Create minimal binary for comparison

zcc +test -vn sieve.c -o sieve -lndos -m -DNOPRINTF
size: 8324 - 115 = 8209 bytes with startup code removed
ticks_start = 0x82, ticks_end = 0x11c from sieve.map
ticks sieve -start 82 -end 11c -counter 99999999999
time: 5,325,739

//////////
SCCZ80 NEW
//////////

1. Verify correct output

zcc +cpm -vn -clib=new sieve.c -o sieve
Rename to com file and run on cpm emulator.

2. Create minimal binary for comparison

zcc +embedded -vn -startup=0 -clib=new sieve.c -o sieve -m -DNOPRINTF
size: 8347 - 111 = 8236 bytes with startup code removed
ticks_start = 0xab, ticks_end = 0x145 from sieve.map
ticks sieve_CODE.bin -start a4 -end 145 -counter 99999999999
time: 5,325,739

////////
SDCC NEW
////////

1. Verify correct output

zcc +cpm -vn -SO3 -clib=sdcc_iy --max-allocs-per-node200000 sieve.c -o sieve
Rename to com file and run on cpm emulator.

2. Create minimal binary for comparison

zcc +embedded -vn -SO3 -startup=0 -DNOPRINTF -clib=sdcc_iy --max-allocs-per-node200000 sieve.c -o sieve -m
size: 8286 - 111 = 8175 bytes without startup code
ticks_start = 0x86, ticks_end = 0x108 from sieve.map
ticks sieve_CODE.bin -start 86 -end 108 -counter 99999999999
time: 3,691,568

zcc +embedded -vn -SO3 -startup=0 -DNOPRINTF -DNOSTAT -clib=sdcc_iy --max-allocs-per-node200000 sieve.c -o sieve -m
size: 8296 - 111 = 8185 bytes without startup code
ticks_start = 0x93, ticks_end = 0x116 from sieve.map
ticks sieve_CODE.bin -start 93 -end 116 -counter 99999999999
time: 6,467,789
