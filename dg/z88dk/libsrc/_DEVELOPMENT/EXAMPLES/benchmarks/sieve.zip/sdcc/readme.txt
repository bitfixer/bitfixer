
SDCC COMPILE


sdcc -mz80 --max-allocs-per-node200000 --reserve-regs-iy sieve.c -o sieve.ihx -DNOPRINTF
hex2bin sieve.ihx
size: _CODE + _DATA = 192 + 8008 = 8200 bytes from sieve.map
ticks_start = 0x217, ticks_end = 0x2bf from sieve.map
ticks sieve.bin -start 217 -end 2bf -counter 99999999999
time: 4,150,710
