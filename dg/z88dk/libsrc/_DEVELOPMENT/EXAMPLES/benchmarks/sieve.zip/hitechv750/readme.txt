
HITECH-C Z80 v7.50 FOR MSDOS

Using the IDE HPDZ.EXE select maximum optimization in compiles.

1. Verify correct output

Compile for CP/M target and run on cpm emulator.

2. Create minimal binary for comparison

* Add "#define NOPRINTF" to source code
* Compile with selections: ROM code, binary image and full optimization.

size (from ide dialog): 159 + 8044 = 8203 (exclude User and first ROM section which correspond to startup code)

ticks_start = 0x102, ticks_end = 0x191 from sieve.sym
ticks sieve.bin -start 102 -end 191 -counter 99999999999
time: 3,672,107
