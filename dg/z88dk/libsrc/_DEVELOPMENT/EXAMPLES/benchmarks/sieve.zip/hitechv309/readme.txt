
HITECH C CPM-80 v3.09 FOR CP/M

1. Verify correct output

C -V -O SIEVE.C
Run on cpm emulator.

2. Create minimal binary for comparison.

C -V -O -DNOPRINTF -MSIEVE.MAP SIEVE.C

size: text - startup + data + bss = 0x2a6 - 0x3d + 2 + 0x1f4a = 8629 bytes from sieve.map
appmake +rom -s 32768 -f 0 -o sieve0.rom
appmake +inject -b sieve0.rom -i sieve.com -s 256 -o sieve.rom
ticks_start = 0x14f, ticks_end = 0x1d2 by inspecting output sieve.com file
ticks sieve.rom -start 14f -end 1d2 -counter 99999999999
time: 4,547,538
