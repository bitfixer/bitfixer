
Z88DK COMPILES

* sccz80 Classic :- sccz80 compiler using classic c library
* sccz80 New     :- sccz80 compiler using new c library
* sccz80 New Fast:- sccz80 compiler using new c library & fast integer math option
* sdcc   New     :- sdcc compiler using new c library
* sdcc   New Fast:- sdcc compiler using new c library & fast integer math option

For each of the above, one run using ldiv() and one without.

//////////////
SCCZ80 CLASSIC
//////////////

1. Verify correct output

zcc +cpm -vn pi_cla.c -o pi -m -DNODIV

2. Create minimal binary for comparison

zcc +test -vn pi_cla.c -o pi -m -DNODIV -DNOPRINTF
size: 6225 - 149 = 6076 bytes without startup code
ticks_start = 0x95, ticks_end = 0x1bd from pi.map
ticks pi -start 95 -end 1bd -counter 99999999999
time: 5,391,413,260

//////////
SCCZ80 NEW
//////////

1. Verify correct output

zcc +cpm -vn -clib=new pi_new.c -o pi -DNODIV
zcc +cpm -vn -clib=new pi_new.c -o pidiv

Change names to end in ".com" and run on cpm emulator.

2. Create minimal binary for comparison.

zcc +embedded -vn -startup=0 -clib=new pi_new.c -o pi -m -DNODIV -DNOPRINTF
size: 6260 - 111 = 6149 bytes without startup code
ticks_start = 0x149, ticks_end = 0x271 from pi.map
ticks pi_CODE.bin -start 149 -end 271 -counter 99999999999
time: 5,246,696,144

zcc +embedded -vn -startup=0 -clib=new pi_new.c -o pidiv -m -DNOPRINTF
size: 6293 - 111 = 6182 bytes without startup code
ticks_start = 0x171, ticks_end = 0x28c from pidiv.map
ticks pidiv_CODE.bin -start 171 -end 28c -counter 99999999999
time: 3,773,744,792

////////
SDCC NEW
////////

1. Verify correct output

zcc +cpm -vn -SO3 -clib=sdcc_iy --max-allocs-per-node200000 pi_new.c -o pi -DNODIV
zcc +cpm -vn -SO3 -clib=sdcc_iy --max-allocs-per-node200000 pi_new.c -o pidiv

Change names to end in ".com" and run on cpm emulator.

2. Create minimal binary for comparison

zcc +embedded -vn -startup=0 -SO3 -clib=sdcc_iy --max-allocs-per-node200000 pi_new.c -o pi -m -DNODIV -DNOPRINTF
size: 6265 - 111 = 6154 bytes without startup code
ticks_start = 0x147, ticks_end = 0x272 from pi.map
ticks pi_CODE.bin -start 147 -end 272 -counter 99999999999
time: 5,285,278,076

zcc +embedded -vn -startup=0 -SO3 -clib=sdcc_iy --max-allocs-per-node200000 pi_new.c -o pidiv -m -DNOPRINTF
size: 6276 - 111 = 6165 bytes without startup code
ticks_start = 0x15c, ticks_end = 0x277 from pidiv.map
ticks pidiv_CODE.bin -start 15c -end 277 -counter 99999999999
time: 3,786,981,324

/////////////////////////////////
PREP FOR FAST INTEGER MATH OPTION
/////////////////////////////////

Edit:  z88dk/libsrc/_DEVELOPMENT/target/cpm/clib_cfg.asm
       change "defc __CLIB_OPT_IMATH = 0" to "defc __CLIB_OPT_IMATH = 75"

Edit:  z88dk/libsrc/_DEVELOPMENT/target/embedded/clib_cfg.asm
       change "defc __CLIB_OPT_IMATH = 0" to "defc __CLIB_OPT_IMATH = 75"

Open command prompt to z88dk/libsrc/_DEVELOPMENT/

Build libraries:
"Winmake cpm embedded" or "make cpm embedded"

(remember to undo these changes after the following compiles)

///////////////
SCCZ80 NEW FAST
///////////////

1. Verify correct output

zcc +cpm -vn -clib=new pi_new.c -o pi -DNODIV
zcc +cpm -vn -clib=new pi_new.c -o pidiv

Change names to end in ".com" and run on cpm emulator.

2. Create minimal binary for comparison.

zcc +embedded -vn -startup=0 -clib=new pi_new.c -o pi -m -DNODIV -DNOPRINTF
size: 7277 - 111 = 7166 bytes without startup code
ticks_start = 0x542, ticks_end = 0x66a from pi.map
ticks pi_CODE.bin -start 542 -end 66a -counter 99999999999
time: 1,953,856,481

zcc +embedded -vn -startup=0 -clib=new pi_new.c -o pidiv -m -DNOPRINTF
size: 7310 - 111 = 7199 bytes without startup code
ticks_start = 0x56a, ticks_end = 0x685 from pidiv.map
ticks pidiv_CODE.bin -start 56a -end 685 -counter 99999999999
time: 1,455,531,292

/////////////
SDCC NEW FAST
/////////////

1. Verify correct output

zcc +cpm -vn -SO3 -clib=sdcc_iy --max-allocs-per-node200000 pi_new.c -o pi -DNODIV
zcc +cpm -vn -SO3 -clib=sdcc_iy --max-allocs-per-node200000 pi_new.c -o pidiv

Change names to end in ".com" and run on cpm emulator.

2. Create minimal binary for comparison

zcc +embedded -vn -startup=0 -SO3 -clib=sdcc_iy --max-allocs-per-node200000 pi_new.c -o pi -m -DNODIV -DNOPRINTF
size: 7282 - 111 = 7171 bytes without startup code
ticks_start = 0x540, ticks_end = 0x66b from pi.map
ticks pi_CODE.bin -start 540 -end 66b -counter 99999999999
time: 1,990,813,171

zcc +embedded -vn -startup=0 -SO3 -clib=sdcc_iy --max-allocs-per-node200000 pi_new.c -o pidiv -m -DNOPRINTF
size: 7293 - 111 = 7182 bytes without startup code
ticks_start = 0x555, ticks_end = 0x670 from pidiv.map
ticks pidiv_CODE.bin -start 15c -end 277 -counter 99999999999
time: 1,467,142,582
