
HITECH C CPM-80 v3.09 FOR CP/M

1. Verify correct output

C -V -O -DNODIV PI.C

Run on cpm emulator.

2. Create minimal binary for comparison.

C -V -O -DNODIV -DNOPRINTF -MPI.MAP PI.C

size: text - startup + data + bss = 0x49d - 0x3d + 2 + 0x15f2 = 6740 bytes from pi.map
appmake +rom -s 32768 -f 0 -o pi0.rom
appmake +inject -b pi0.rom -i pi.com -s 256 -o pi.rom
ticks_start = 0x13d, ticks_end = 0x24c by inspecting output pi.com file
ticks pi.rom -start 13d -end 24c -counter 99999999999
time: 5,465,797,961
