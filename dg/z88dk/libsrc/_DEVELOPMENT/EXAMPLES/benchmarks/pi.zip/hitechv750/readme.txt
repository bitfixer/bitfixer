
HITECH-C Z80 v7.50 FOR MSDOS

Using the IDE HPDZ.EXE select maximum optimization in compiles.

1. Verify correct output

Compile for CP/M target and run on cpm emulator.

2. Create minimal binary for comparison

* Add "#define NOPRINTF" to source code
* Compile with selections: ROM code, binary image and full optimization.

size (from ide dialog): 807 + 5666 = 6473 (exclude User and first ROM section which correspond to startup code)

Manually investigate binary to locate where ticks_start and ticks_end are.
ticks_start = 0xf4, ticks_end = 0x1f3

ticks pi.bin -start f4 -end 1f3 -counter 99999999999
time: 5,884,343,627

* Add another define "#define NODIV" to source code
* Compile with selections: ROM code, binary image and full optimization.

size (from ide dialog): 680 + 5652 = 6332 (exclude User and first ROM section which correspond to startup code)

Manually investigate binary to locate where ticks_start and ticks_end are.
ticks_start = 0xf4, ticks_end = 0x1f2

ticks pi.bin -start f4 -end 1f2 -counter 99999999999
time: 5,520,762,227


Note that the version using ldiv() is actually slower than the version without it.
Hitech C does not seem to get a quotient and remainder from a single division.
