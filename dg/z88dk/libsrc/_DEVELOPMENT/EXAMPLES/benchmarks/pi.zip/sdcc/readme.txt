
SDCC COMPILE


sdcc -mz80 -DNODIV -DNOPRINTF --max-allocs-per-node200000 --reserve-regs-iy pi.c -o pi.ihx
hex2bin pi.ihx
size: _CODE + _HOME + _DATA = 490 + 699 + 5616 = 6805 bytes from pi.map
ticks_start = 0x217, ticks_end = 0x3c6 from pi.map
ticks pi.bin -start 217 -end 3c6 -counter 99999999999
time: 8,892,037,196

sdcc -mz80 -DNODIV -DNOPRINTF --max-allocs-per-node200000 pi.c -o pi.ihx
hex2bin pi.ihx
size: _CODE + _HOME + _DATA = 474 + 699 + 5616 = 6789 bytes from pi.map
ticks_start = 0x217, ticks_end = 0x3b6 from pi.map
ticks pi.bin -start 217 -end 3b6 -counter 99999999999
time: 8,920,908,807

sdcc -mz80 -DNODIV -DNOPRINTF -DNOSTAT --max-allocs-per-node200000 --reserve-regs-iy pi.c -o pi.ihx
hex2bin pi.ihx
size: _CODE + _HOME + _DATA = 452 + 699 + 5604 = 6755 bytes from pi.map
ticks_start = 0x217, ticks_end = 0x3a0 from pi.map
ticks pi.bin -start 217 -end 3a0 -counter 99999999999
time: 9,006,923,524
